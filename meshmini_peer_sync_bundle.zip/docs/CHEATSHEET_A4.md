# MeshMini — Cheatsheet (A4)

`?` menu · `??` help

**User**
- `r` · `r <id>`
- `p <text>` · `reply <id> <text>`
- `info` · `status`
- `whoami` · `whois <short>` · `nodes`
- `dm <short> <text>` (queued if offline)

**Admin**
- `admins add|del <!id>` · `admins list`
- `bl add|del <!id>` · `bl list`
- `peer add|del <!id>` · `peer list`
- `sync now|on|off`
- `info set <text>`
